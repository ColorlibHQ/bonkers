<?php
/**
 * Olivo Shortcodes
 *
 * @package   Olivo_Shortcodes
 * @author    Quema Labs
 * @license   GPL-2.0+
 * @link      https://www.quemalabs.com/
 * @copyright 2017 Quema Labs
 *
 * @wordpress-plugin
 * Plugin Name: Olivo Shortcodes
 * Plugin URI:  https://www.quemalabs.com/
 * Description: Shortcodes for Olivo theme.
 * Version:     1.0.0
 * Author:      Quema Labs
 * Author URI:  https://www.quemalabs.com/
 * Text Domain: olivo-shortcodes
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


/**
* Function for Adding Quema Labs Carousel Component on vc_init hook
*
* @param void
*
* @return void
*/
function olivo_shortcodes_component_carousel() {
    vc_map(
        array(
            'name' => esc_html__( 'Quema Labs Carousel', 'olivo-shortcodes' ),
            'base' => 'olivo_shortcodes_carousel',
            'category' => esc_html__( 'Content', 'olivo-shortcodes' ),
            'icon' => plugin_dir_url( __FILE__ ) . '/images/ql_carousel.png',
            'params' => array(
                array(
                    'type' => 'attach_images',
                    'class' => '',
                    'heading' => esc_html__( 'Images', 'olivo-shortcodes' ),
                    'param_name' => 'images',
                    'value' => '',
                    'description' => esc_html__( 'Images for the carousel', 'olivo-shortcodes' ),
                ),
            )
        )
    );
}
add_action( 'vc_before_init', 'olivo_shortcodes_component_carousel' );


/**
* Function for displaying Quema Labs Carousel functionality
*
* @return string $html - the HTML content for this shortcode.
*/
function olivo_shortcodes_carousel_function( $atts, $content ) {

    $html = '';
    $atts = shortcode_atts(
        array(
            'images' => '',
        ), $atts, 'olivo_shortcodes_carousel'
    );
    $images_array = explode(',', $atts['images']);    

    if ( $atts['images'] ) {
        $html .='<div class="olivo_shortcodes_carousel">';
        foreach ( $images_array as $image ) {
            $carousel_image = wp_get_attachment_image( $image, 'glaciar_portfolio' );
            $carousel_image_src = wp_get_attachment_image_src( $image, 'full' );
            $html .= <<<EOD
                <div class="image-slide">
                    <a href="{$carousel_image_src[0]}" data-width="{$carousel_image_src[1]}" data-height="{$carousel_image_src[2]}">
                        {$carousel_image}
                    </a>
                </div>
EOD;
        }
        $html .= "</div>";
        $html .='<div class="olivo_shortcodes_carousel_thumbnails">';
        foreach ( $images_array as $image ) {
            $carousel_image = wp_get_attachment_image( $image, 'thumbnail' );
            $html .= <<<EOD
                <div class="image-slide">
                    {$carousel_image}
                </div>
EOD;
        }
        $html .= "</div>";

    }
    return $html;
}
add_shortcode( 'olivo_shortcodes_carousel', 'olivo_shortcodes_carousel_function' );
