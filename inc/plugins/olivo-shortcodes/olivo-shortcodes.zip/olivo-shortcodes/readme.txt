=== Olivo Shortcodes ===
Contributors: nicoandrade
Tags: shortcodes
Requires at least: 3.7
Tested up to: 4.7.2
Stable tag: 1.0.1
License: GPLv2 or later


== Description ==

This plugins adds several shortcodes to your theme, including shortcodes that will work with Visual Composer.


== Installation ==

Just install and activate.


== Changelog ==

= 1.0.0 =

* Initial release
